﻿

namespace StockPrice.Settings
{
    public sealed class HyperMagicSettings
    {
        /// <summary>
        /// ApiKey for https://hm.ru/
        /// </summary>
        public string ApiKey { get; set; }
    }
}
