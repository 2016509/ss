﻿using Dapper;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using StockPrice.DatabaseClasses;
using StockPrice.Methods.TableWorks;
using StockPrice.Methods.TableWorks.Classes;
using StockPrice.ResponseClasses;
using StockPrice.Settings;
using StockPrice.SiteMethods.Canada_Sites;
using System.Collections.Generic;
using StockPrice.SiteMethods.USA_Sites;
using Telegram.Bot;
using TaskStatus = StockPrice.DatabaseClasses.TaskStatus;

namespace StockPrice.Methods
{
    public class InfoCollector
    {
        public static async Task MainTracker(ITelegramBotClient botClient, CancellationToken cancellationToken)
        {
            Console.WriteLine("MainTracker has been started!");
            while (!cancellationToken.IsCancellationRequested)
            {
                var cs = @$"Server={AppSettings.Current.Database.Host};Port={AppSettings.Current.Database.Port};User={AppSettings.Current.Database.Login};Database={AppSettings.Current.Database.Database};Password={AppSettings.Current.Database.Password}";
                await using var con = new MySqlConnection(cs);
                con.Open();
                int count = await con.QueryFirstAsync<int>($"SELECT COUNT(*) FROM totalresults WHERE `workStarted`=0 AND `status`='{(int)TaskStatus.Created}'");
                if (count > 0)
                {
                    var requests = await con.QueryAsync<DatabaseTotalResults>($"SELECT * FROM totalresults WHERE `workStarted`=0");

                    foreach (var response in requests)
                    {
                        await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `workStarted`='1', `status`='{(int)TaskStatus.WorkStarted}' WHERE `ID`='{response.ID}';");
                        _ = MainSender(botClient, cancellationToken, response); //Запускаем таск, отвечающий за отправку результатов
                    }
                }
                await con.CloseAsync(cancellationToken);
                Thread.Sleep(250);


            }

            
        }

        private static async Task MainSender(ITelegramBotClient botClient, CancellationToken cancellationToken, DatabaseTotalResults request)
        {


            var cs = @$"Server={AppSettings.Current.Database.Host};Port={AppSettings.Current.Database.Port};User={AppSettings.Current.Database.Login};Database={AppSettings.Current.Database.Database};Password={AppSettings.Current.Database.Password}";
            await using var con = new MySqlConnection(cs);
            await con.OpenAsync(cancellationToken);
            var settings = con.QueryFirstOrDefault<DatabaseUserData>($"SELECT * FROM userdata WHERE `userId`={request.ChatID}");
            await con.CloseAsync(cancellationToken);

            if (settings == null)
            {
                
                var sendedMessage = await botClient.SendTextMessageAsync(
               chatId: request.ChatID,
               text: $"Your are not registered. Write a /start",
               parseMode: Telegram.Bot.Types.Enums.ParseMode.Html,
               disableWebPagePreview: true,
               cancellationToken: cancellationToken
                   );
                

                await con.OpenAsync(cancellationToken);
                await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `botMessageID`='{sendedMessage.MessageId}', `ResponseSent`='{DateTime.Now:yyyy-MM-dd HH:mm:ss}', `status`='{(int)TaskStatus.Sended}' WHERE `ID`='{request.ID}'");
                await con.CloseAsync(cancellationToken);
                Thread.Sleep(1000);
                return;
            }

            await con.OpenAsync(cancellationToken);
            await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `status`='{(int)TaskStatus.WorkStarted}' WHERE `ID`='{request.ID}'");
            await con.CloseAsync(cancellationToken);

            var mainPriceResponsesList = new List<MainPriceResponse>();
            var tableResponses = new List<StockTable>();



            List<Task> allTasks = new();

            //  [-1] Запуск потока для работы с таблицей
            if (settings.IsHaveStockTable) allTasks.Add(Task.Run(() => TableMainClass.ReadTable(request, tableResponses), cancellationToken));

            if (settings.ParseCanada)
            {
                
                //  [0] Запуск потока для   AppliancepartshqCA
                if (settings.AppliancepartshqCA) allTasks.Add(Task.Run(() => AppliancePartsHq.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [1] Запуск потока для   PartsexpertCa
                if (settings.PartsexpertCa) allTasks.Add(Task.Run(() => PartsExpert.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [2] Запуск потока для   PartselectCA
                if (settings.PartselectCA) allTasks.Add(Task.Run(() => PartselectCa.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [3] Запуск потока для   ReliablepartsCA
                if (settings.ReliablepartsCA) allTasks.Add(Task.Run(() => ReliablePartsCanada.Parsing(request, mainPriceResponsesList), cancellationToken));
                //allTasks.Add(Task.Run(() => ReliablePartsCanada.MakeAlternativeLinkFromReliablePartsCa(request, MainPriceResponsesList)));



                //  [4] Запуск потока для   EasyappliancepartsCA
                if (settings.EasyappliancepartsCA) allTasks.Add(Task.Run(() => EasyApplianceParts.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [5] Запуск потока для   AmresupplyCOM
                if (settings.AmresupplyCOM) allTasks.Add(Task.Run(() => AmreSupply.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [6] Запуск потока для   AppliancepartsCanadaCom
                if (settings.AppliancepartsCanadaCom) allTasks.Add(Task.Run(() => AppliancePartsCanada.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [7] Запуск потока для   ApwagnerCA
                if (settings.ApwagnerCA) allTasks.Add(Task.Run(() => ApwagnerCa.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [8] Запуск потока для   BulbsproCOM
                if (settings.BulbsproCOM) allTasks.Add(Task.Run(() => BulbsPro.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [9] Запуск потока для   MajorappliancepartsCA
                if (settings.MajorappliancepartsCA) allTasks.Add(Task.Run(() => MajorApplianceParts.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [10] Запуск потока для   AmazonCA
                if (settings.AmazonCA) allTasks.Add(Task.Run(() => AmazonCa.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [11] Запуск потока для   MarconeCanada
                if (settings.MarconeCanada) allTasks.Add(Task.Run(() => BetaMarconeCanada.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [12] Запуск потока для   EbayCA
                if (settings.EbayCA) allTasks.Add(Task.Run(() => EbayCa.Parsing(request, mainPriceResponsesList), cancellationToken));
            }


            if (settings.ParseUSA)
            {
                
                //  [13] Запуск потока для   EnCompass
                if (settings.EncompassCOM) allTasks.Add(Task.Run(() => EncompassCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [14] Запуск потока для   CoastParts
                if (settings.CoastPartsCOM) allTasks.Add(Task.Run(() => CoastParts.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [15] Запуск потока для   GuaranteedParts
                if (settings.GuaranteedPartsCOM) allTasks.Add(Task.Run(() => GuaranteedParts.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [16] Запуск потока для   PartsDr
                if (settings.PartsDrCOM) allTasks.Add(Task.Run(() => Partsdr.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [17] Запуск потока для   AppliancePartsPros
                if (settings.AppliancePartsProsCOM) allTasks.Add(Task.Run(() => AppliancePartsPros.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [18] Запуск потока для   PartSelectCOM
                if (settings.PartSelectCOM) allTasks.Add(Task.Run(() => PartselectCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [19] Запуск потока для   ApplianceParts365
                if (settings.ApplianceParts365COM) allTasks.Add(Task.Run(() => ApplianceParts365.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [20] Запуск потока для   ApwagnerCom
                if (settings.ApwagnerCOM) allTasks.Add(Task.Run(() => ApwagnerCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [21] Запуск потока для   SearsPartsDirect
                if (settings.SearsPartsDirectCOM) allTasks.Add(Task.Run(() => SearsPartsDirect.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [22] Запуск потока для   ReliablePartsCom
                if (settings.ReliablePartsCom) allTasks.Add(Task.Run(()=> ReliablePartsUsa.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [23] Запуск потока для   EbayCOM
                if (settings.EbayCOM) allTasks.Add(Task.Run(() => EbayCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [24] Запуск потока для   AmazonCOM
                if (settings.AmazonCOM) allTasks.Add(Task.Run(() => AmazonCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [25] Запуск потока для   DLPartscoCOM
                if (settings.DlPartsCoCom) allTasks.Add(Task.Run(()=> DlPartscoCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [26] Запуск потока для   CashWellsCOM
                if (settings.CashWellsCom) allTasks.Add(Task.Run(() => CashWellsCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [27] Запуск потока для   RepairClinicCom
                if (settings.RepairClinicCom) allTasks.Add(Task.Run(() => RepairClinicCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [28] Запуск потока для   PartsTownCom
                if (settings.PartsTownCom) allTasks.Add(Task.Run(() => PartsTownCom.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [29] Запуск потока для   AllVikingParts
                if (settings.AllVikingPartsCom) allTasks.Add(Task.Run(() => AllVikingParts.Parsing(request, mainPriceResponsesList), cancellationToken));

                //  [11] Запуск потока для   MarconeUsa
                if (settings.MarconeUsa) allTasks.Add(Task.Run(() => BetaMarconeUsa.Parsing(request, mainPriceResponsesList), cancellationToken));
            }
            


            if (!request.IsMassTestingRequest)
            {
                await AutoUpdatedMessage.MainUpdater(botClient, cancellationToken, request, allTasks);
            }




            Task.WaitAll(allTasks.ToArray());
            //Console.ReadLine();

            await botClient.DeleteMessageAsync(chatId: request.ChatID, messageId: (int)request.BotMessageID, cancellationToken: cancellationToken);


            var text = await MakeResponse(request, mainPriceResponsesList, tableResponses);

            if (text == null)
            {
                if (!request.IsMassTestingRequest)
                    await botClient.SendTextMessageAsync(
                        chatId: request.ChatID,
                        text: "No results.",
                        parseMode: Telegram.Bot.Types.Enums.ParseMode.Html,
                        disableWebPagePreview: true,
                        cancellationToken: cancellationToken
                    );
                /*await botClient.EditMessageTextAsync(
           chatId: request.ChatID,
           text: "No results.",
           messageId: (int)request.BotMessageID,
           parseMode: Telegram.Bot.Types.Enums.ParseMode.Html,
           disableWebPagePreview: true,
           cancellationToken: cancellationToken
           );*/
                return;
            }


            if (!request.IsMassTestingRequest)
            {
                again:
                try
                {
                    var sendedMessage = await botClient.SendTextMessageAsync(
                        chatId: request.ChatID,
                        text: text + Environment.NewLine + Environment.NewLine + $"✅ Search completed",
                        parseMode: Telegram.Bot.Types.Enums.ParseMode.Html,
                        disableWebPagePreview: true,
                        cancellationToken: cancellationToken);
                    /* var sendedMessage = await botClient.EditMessageTextAsync(
                    chatId: request.ChatID,
                    text: text + Environment.NewLine + Environment.NewLine + $"✅ Search completed",
                    messageId: (int)request.BotMessageID,
                    parseMode: Telegram.Bot.Types.Enums.ParseMode.Html,
                    disableWebPagePreview: true,
                    cancellationToken: cancellationToken
                        );*/


                    await con.OpenAsync(cancellationToken);
                    await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `botMessageID`='{sendedMessage.MessageId}', `status`='{(int)TaskStatus.Sended}', `ResponseSent`='{DateTime.Now:yyyy-MM-dd HH:mm:ss}' WHERE `ID`='{request.ID}'");
                    await con.CloseAsync(cancellationToken);
                }
                catch(Exception ex)
                {
                    Console.WriteLine($"Send result error: {ex.Message}");
                
                    Thread.Sleep(1000);
                    goto again;
                }
                
            }
            
        }




        private static string? ModifyTitle(string? title, string search)
        {
            if (title == null) return title;
            string newSearch = search.ToUpper();
            while (true)
            {
                if (newSearch.Length <= 2) break; ;

                if (title.Contains(newSearch))
                {
                    return title.Replace(newSearch, $"<b>{newSearch}</b>");
                }
                else
                {
                    newSearch = newSearch.Remove(newSearch.Length - 1, 1);
                }
            }

            newSearch = search.ToLower();

            while (true)
            {
                if (newSearch.Length <= 2) return title;

                if (title.Contains(newSearch))
                {
                    return title.Replace(newSearch, $"<b>{newSearch}</b>");
                }
                else
                {
                    newSearch = newSearch.Remove(newSearch.Length - 1, 1);
                }
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request">Request from BD</param>
        /// <param name="mainPriceResponsesList">List with results search</param>
        /// <param name="tableResponses">Table with responses</param>
        /// <param name="updateDbData">Update db or not</param>
        /// <returns></returns>
        public static async Task<string?> MakeResponse(
            DatabaseTotalResults request,
            List<MainPriceResponse> mainPriceResponsesList,
            List<StockTable> tableResponses,
            bool updateDbData = true)
        {
            var cs = @$"Server={AppSettings.Current.Database.Host};Port={AppSettings.Current.Database.Port};User={AppSettings.Current.Database.Login};Database={AppSettings.Current.Database.Database};Password={AppSettings.Current.Database.Password}";

            string totalText = null;



            mainPriceResponsesList = mainPriceResponsesList.OrderBy(x => x.LowestPrice).ToList(); //Сортируем по цене от меньшей к большей.

            var readySendMainPriceResponseList = mainPriceResponsesList.Where(x => x.PricesList != null && x.PricesList.Count > 0 && !x.NoAnswerOrError && !x.NothingFoundOrOutOfStock).ToList();
            var responseWithOutOfStockOrNothingFound = mainPriceResponsesList.Where(x => x.NothingFoundOrOutOfStock && !x.NoAnswerOrError).ToList();
            var responseWithErrors = mainPriceResponsesList.Where(x => x.NoAnswerOrError).ToList();

            List<string> responsesStringify = new();

            foreach (var takenResp in readySendMainPriceResponseList)
            {
                string readyString = null;

                if (takenResp.PricesList.Count > 1)
                {
                    takenResp.PricesList = takenResp.PricesList.OrderBy(x => x.Price).ToList();
                }

                if (takenResp.MultiChoice)
                    if(takenResp.AlternativeSearchLink == null)
                        if (takenResp.Additional == null)
                            readyString += $@"<b>{takenResp.Source}-></b><a href='{takenResp.SearchUrl}'>(All results)</a>->  ";
                        else
                            readyString += $@"<b>{takenResp.Source}</b>{takenResp.Additional}<a href='{takenResp.SearchUrl}'>(All results)</a>->  ";
                    else
                        if (takenResp.Additional == null)
                        readyString += $@"<b>{takenResp.Source}-></b><a href='{takenResp.AlternativeSearchLink}'>(All results)</a>->  ";
                    else
                        readyString += $@"<b>{takenResp.Source}</b>{takenResp.Additional}<a href='{takenResp.AlternativeSearchLink}'>(All results)</a>->  ";


                else
                    if (takenResp.Additional == null)
                    readyString += $@"<b>{takenResp.Source}-></b>  ";
                else
                    readyString += $@"<b>{takenResp.Source}</b>{takenResp.Additional}->  ";


                List<string> pricesStringify = new();

                foreach (var price in takenResp.PricesList)
                {

                    string pricePrepare = null;
                    //if (price.DeliveryPrice > 0) price_prepare += $@" 📦${price.DeliveryPrice.ToString().Replace(',', '.')}";

                    if (price.DoublePrice != null)
                    {
                        if (price.Availability != null) pricePrepare += $"{price.Availability}-> ";
                        if (price.Title != null && takenResp.PricesList.IndexOf(price) == 0) pricePrepare += $@" {price.Title.Substring(0, Math.Min(price.Title.Length, 80)).Replace("#", "")} ";
                        if (takenResp.AlternativeLink == null) pricePrepare += $@"<a href='{price.Url}'>{price.DoublePrice}</a>";
                        else
                        {
                            var dbPriceSplit = price.DoublePrice.Split('/');
                            pricePrepare += $@"<a href='{price.Url}'>{dbPriceSplit[0].Trim()}</a> / <a href='{takenResp.AlternativeLink}'>{dbPriceSplit[1].Trim()}</a>";
                        }
                    }
                    else
                    {

                        if (price.Availability != null) pricePrepare += $"{price.Availability}-> ";
                        if (price.Title != null && takenResp.PricesList.IndexOf(price) == 0) pricePrepare += $@" {price.Title.Substring(0, Math.Min(price.Title.Length, 80)).Replace("#", "")} ";
                        pricePrepare += $@"<a href='{price.Url}'>${price.Price.ToString().Replace(',', '.')}</a>";
                    }


                    if (price.DeliveryDays != null) pricePrepare += $"_{price.DeliveryDays}d";
                    if (price.DeliveryPrice > 0) pricePrepare += $"+{price.DeliveryPrice.ToString().Replace(",", ".")}";

                    pricesStringify.Add(pricePrepare);
                }

                readyString += string.Join("; ", pricesStringify);
                if (takenResp.Locations != null && takenResp.Locations.Count > 0)
                    readyString += Environment.NewLine + "• " + String.Join(Environment.NewLine + "• ", takenResp.Locations);

                if (takenResp.EndAdditional != null)
                    readyString += $@" {takenResp.EndAdditional}";

                totalText += readyString + Environment.NewLine;

                

            }

            if (responseWithOutOfStockOrNothingFound.Count > 0)
            {
                responseWithOutOfStockOrNothingFound = responseWithOutOfStockOrNothingFound.OrderBy(x => x.Source).ToList();
                totalText += Environment.NewLine + Environment.NewLine + @"<b>Nothing found / Out of stock</b>";
                foreach (var response in responseWithOutOfStockOrNothingFound)
                {
                    totalText += Environment.NewLine + $@"<a href='{response.SearchUrl}'>{response.Source}</a>";
                }
            }

            if (responseWithErrors.Count > 0)
            {
                responseWithErrors = responseWithErrors.OrderBy(x=>x.Source).ToList();
                totalText += Environment.NewLine + Environment.NewLine + @"<b>No answer / Error</b>";
                foreach (var response in responseWithErrors)
                {
                    totalText += Environment.NewLine + $@"<a href='{response.SearchUrl}'>{response.Source}</a>";
                }
            }

            if (tableResponses.Count > 0)
            {
                totalText += Environment.NewLine + $@"<b>Stock data:</b>";
                foreach (var stockRow in tableResponses)
                {
                    if (stockRow.Sku != null) totalText += Environment.NewLine + $@"<b>#: </b>{stockRow.Sku}";
                    if (stockRow.Name != null) totalText += Environment.NewLine + $@"<b>Name: </b>{stockRow.Name}";
                    if (stockRow.Quantity != null) totalText += Environment.NewLine + $@"<b>Qty: </b>{stockRow.Quantity}";
                    if (stockRow.Condition != null) totalText += $@" // <b>Cond: </b>{stockRow.Condition}";
                    if (stockRow.WareHouse != null) totalText += $@" // <b>Wh#: </b>{stockRow.WareHouse}";
                    if (stockRow.Comment != null) totalText += Environment.NewLine + $@"<b>Cmt: </b>{stockRow.Comment}";
                }
            }
            else
            {
                totalText += Environment.NewLine + $@"<b>You do not have part {request.Request} or replaces in your stock</b>";
            }

            if (totalText != null) totalText = totalText.Trim();
            var jResponseSended = JsonConvert.SerializeObject(readySendMainPriceResponseList, Formatting.None);
            var jResponseFull = JsonConvert.SerializeObject(mainPriceResponsesList.OrderBy(x => x.Source).ToList(), Formatting.None);

            string escapedSended = MySqlHelper.EscapeString(jResponseSended);
            string escapedFull = MySqlHelper.EscapeString(jResponseFull);
            if (updateDbData)
            {
                await using var con = new MySqlConnection(cs);
                await con.OpenAsync(CancellationToken.None);
                try
                {
                    await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `sendedResult`='{escapedSended}' WHERE `ID`={request.ID};");
                    await con.QueryFirstOrDefaultAsync($"UPDATE totalresults SET `fullResult`='{escapedFull}' WHERE `ID`={request.ID};");
                }
                catch
                {
                    // ignore
                }
                await con.CloseAsync();
            }
            
            return totalText;
        }



    }


}
